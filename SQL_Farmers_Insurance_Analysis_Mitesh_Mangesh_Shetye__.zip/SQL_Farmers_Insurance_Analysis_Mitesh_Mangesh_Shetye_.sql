-- Name: Mitesh Mangesh Shetye
-- Assignment Title: SQL Farmers Insurance Analysis

-- 1. Total number of policies
SELECT COUNT(*) AS total_policies FROM policies;

-- 2. Policies by region
SELECT region, COUNT(*) AS policy_count
FROM policies
GROUP BY region;

-- 3. Average claim amount by policy type
SELECT policy_type, AVG(claim_amount) AS avg_claim
FROM claims
GROUP BY policy_type;

-- 4. Top 5 customers by total premium paid
SELECT customer_id, SUM(premium_amount) AS total_premium
FROM policies
GROUP BY customer_id
ORDER BY total_premium DESC
LIMIT 5;

-- 5. Claims ratio by policy type
SELECT policy_type,
       SUM(CASE WHEN claim_amount > 0 THEN 1 ELSE 0 END) / COUNT(*) AS claim_ratio
FROM claims
GROUP BY policy_type;

-- 6. Monthly trend of claims
SELECT DATE_FORMAT(claim_date, '%Y-%m') AS month,
       COUNT(*) AS total_claims
FROM claims
GROUP BY month
ORDER BY month;

-- 7. Average policy duration
SELECT AVG(DATEDIFF(policy_end_date, policy_start_date)) AS avg_policy_duration_days
FROM policies;

-- 8. Region-wise claim amount summary
SELECT region,
       SUM(claim_amount) AS total_claims,
       AVG(claim_amount) AS avg_claim,
       MAX(claim_amount) AS max_claim
FROM claims
JOIN policies ON claims.policy_id = policies.policy_id
GROUP BY region;
