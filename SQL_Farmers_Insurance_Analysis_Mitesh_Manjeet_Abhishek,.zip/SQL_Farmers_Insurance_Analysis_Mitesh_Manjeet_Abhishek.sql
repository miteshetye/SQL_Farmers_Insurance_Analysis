-- SELECT Queries

-- 1. Retrieve the names of all states (srcStateName).
SELECT DISTINCT srcStateName
FROM FarmersInsurance;


-- 2. RetrieveTotalFarmersCoveredandSumInsuredfor  each  state,  ordered  descending  byTotalFarmersCovered
SELECT 
    srcStateName,
    SUM(TotalFarmersCovered) AS TotalFarmersCovered,
    SUM(SumInsured) AS TotalSumInsured
FROM 
    FarmersInsurance
GROUP BY 
    srcStateName
ORDER BY 
    TotalFarmersCovered DESC;



-- filtering Data (WHERE)

-- 3. Retrieve records whereYearis 2020
SELECT *
FROM FarmersInsurance
WHERE srcYear = 2020;


-- 4. Retrieve records whereTotalPopulationRural > 10,00,000andsrcStateName = "HIMACHALPRADESH"
SELECT *
FROM FarmersInsurance
WHERE TotalPopulationRural > 1000000
  AND srcStateName = 'HIMACHALPRADESH';


-- 5. Retrieve thesrcStateName,srcDistrictName, and the sum ofFarmersPremiumAmountfor eachdistrict in the year 2018, ordered byFarmersPremiumAmountin ascending order
SELECT 
    srcStateName,
    srcDistrictName,
    SUM(FarmersPremiumAmount) AS TotalFarmersPremium
FROM 
    FarmersInsurance
WHERE 
    srcYear = 2018
GROUP BY 
    srcStateName, srcDistrictName
ORDER BY 
    TotalFarmersPremium ASC;


-- 6. Retrieve the total number of farmers covered and the sum of the gross premium amount to bepaid for each state where the insured land area is greater than 5.0 for the year 2018.
SELECT 
    srcStateName,
    SUM(TotalFarmersCovered) AS TotalFarmersCovered,
    SUM(FarmersPremiumAmount + StatePremiumAmount + CentralPremiumAmount) AS GrossPremiumAmount
FROM 
    FarmersInsurance
WHERE 
    srcYear = 2018
    AND InsuredLandArea > 5.0
GROUP BY 
    srcStateName;




-- agregation (GROUP BY)

-- 7. Calculate averageInsuredLandAreafor each year
SELECT 
    srcYear,
    AVG(InsuredLandArea) AS AvgInsuredLandArea
FROM 
    FarmersInsurance
GROUP BY 
    srcYear;


-- 8. CalculateTotalFarmersCoveredfor each district whereInsuranceUnits > 0.
SELECT 
    srcDistrictName,
    SUM(TotalFarmersCovered) AS TotalFarmersCovered
FROM 
    FarmersInsurance
WHERE 
    [Insurance units] > 0
GROUP BY 
    srcDistrictName;


-- 9. Calculate total premiums andTotalFarmersCoveredfor each state where totalSumInsured >5,00,000INR.
SELECT 
    srcStateName,
    SUM(FarmersPremiumAmount + StatePremiumAmount + CentralPremiumAmount) AS TotalPremiumAmount,
    SUM(TotalFarmersCovered) AS TotalFarmersCovered
FROM 
    FarmersInsurance
WHERE 
    SumInsured > 500000
GROUP BY 
    srcStateName;



-- Sorting Data

-- 10. Retrieve the top 5 districts with the highest total population in 2020.
SELECT TOP 5
    srcDistrictName,
    srcStateName,
    (TotalPopulationUrban + TotalPopulationRural) AS TotalPopulation
FROM 
    FarmersInsurance
WHERE 
    srcYear = 2020
ORDER BY 
    TotalPopulation DESC;


-- 11. RetrievesrcStateName,srcDistrictName, andSumInsuredfor the 10 districts with lowestnon-zero farmers� premium amount, ordered by insured sum and premium amount.
SELECT TOP 10
    srcStateName,
    srcDistrictName,
    SumInsured,
    FarmersPremiumAmount
FROM 
    FarmersInsurance
WHERE 
    FarmersPremiumAmount > 0
ORDER BY 
    FarmersPremiumAmount ASC, SumInsured ASC;


-- 12. Retrieve top 3 states for each year with highest insured farmers to total population ratio, orderedby the ratio
WITH RatioRanked AS (
    SELECT 
        srcYear,
        srcStateName,
        SUM(TotalFarmersCovered) AS TotalFarmers,
        SUM(TotalPopulationUrban + TotalPopulationRural) AS TotalPopulation,
        CAST(SUM(TotalFarmersCovered) AS FLOAT) / NULLIF(SUM(TotalPopulationUrban + TotalPopulationRural), 0) AS CoverageRatio,
        ROW_NUMBER() OVER (PARTITION BY srcYear ORDER BY 
            CAST(SUM(TotalFarmersCovered) AS FLOAT) / NULLIF(SUM(TotalPopulationUrban + TotalPopulationRural), 0) DESC
        ) AS rn
    FROM 
        FarmersInsurance
    GROUP BY 
        srcYear, srcStateName
)
SELECT 
    srcYear,
    srcStateName,
    TotalFarmers,
    TotalPopulation,
    CoverageRatio
FROM 
    RatioRanked
WHERE 
    rn <= 3
ORDER BY 
    srcYear, CoverageRatio DESC;



-- STRING FUNCTION

-- 13. Retrieve the first 3 characters of thesrcStateNameto createStateShortName
SELECT 
    srcStateName,
    LEFT(srcStateName, 3) AS StateShortName
FROM 
    FarmersInsurance;


--  RetrievesrcDistrictNamewhere the district name starts with"B".
SELECT 
    srcDistrictName
FROM 
    FarmersInsurance
WHERE 
    srcDistrictName LIKE 'B%';


-- RetrievesrcStateNameandsrcDistrictNamewhere district name ends with"pur".
SELECT 
    srcStateName,
    srcDistrictName
FROM 
    FarmersInsurance
WHERE 
    srcDistrictName LIKE '%pur';



-- Joins

-- INNER JOINsrcStateNameandsrcDistrictNameto retrieve the aggregated farmers� premiumamount for districts where the Insurance units for an individual year are greater than 10
SELECT 
    srcStateName,
    srcDistrictName,
    srcYear,
    SUM(FarmersPremiumAmount) AS TotalFarmersPremium
FROM 
    FarmersInsurance
WHERE 
    [Insurance units] > 10
GROUP BY 
    srcStateName, srcDistrictName, srcYear;


-- RetrievesrcStateName,srcDistrictName,Year,TotalPopulationfor each district and thethe highest recorded farmers premium amount for that district over all available years. Returnonly those districts where the highest amount exceeds 20 crore
WITH DistrictMaxPremium AS (
    SELECT 
        srcStateName,
        srcDistrictName,
        srcYear,
        (TotalPopulationUrban + TotalPopulationRural) AS TotalPopulation,
        FarmersPremiumAmount,
        MAX(FarmersPremiumAmount) OVER (PARTITION BY srcDistrictName) AS MaxPremium
    FROM 
        FarmersInsurance
)
SELECT 
    srcStateName,
    srcDistrictName,
    srcYear,
    TotalPopulation,
    MaxPremium AS HighestFarmersPremium
FROM 
    DistrictMaxPremium
WHERE 
    MaxPremium > 200000000;  -- 20 crores



--Perform a LEFT JOIN to combine the total population statistics with the farmers� data for eachdistrict and state. Return the total premium amount and the average population count for eachdistrict aggregated over the years, where the total premium amount is greater than 100 crores.Sort the results by total farmers� premium amount, highest first


SELECT 
    srcStateName,
    srcDistrictName,
    SUM(FarmersPremiumAmount + StatePremiumAmount + CentralPremiumAmount) AS TotalPremiumAmount,
    AVG(CAST(TotalPopulationUrban + TotalPopulationRural AS FLOAT)) AS AvgPopulation
FROM 
    FarmersInsurance
GROUP BY 
    srcStateName, srcDistrictName
HAVING 
    SUM(FarmersPremiumAmount + StatePremiumAmount + CentralPremiumAmount) > 1000000000  -- 100 crores
ORDER BY 
    TotalPremiumAmount DESC;



--Subqueries

-- 19. Find districts where the total farmers covered is greater than average total farmers covered acrossall records
SELECT 
    srcDistrictName,
    SUM(TotalFarmersCovered) AS DistrictFarmersCovered
FROM 
    FarmersInsurance
GROUP BY 
    srcDistrictName
HAVING 
    SUM(TotalFarmersCovered) > (
        SELECT AVG(TotalFarmersCovered * 1.0)
        FROM FarmersInsurance
    );

--  FindsrcStateNamewhere insured sum is higher than insured sum of the district with the highestfarmers� premium amount
SELECT 
    srcStateName,
    SUM(SumInsured) AS StateSumInsured
FROM 
    FarmersInsurance
GROUP BY 
    srcStateName
HAVING 
    SUM(SumInsured) > (
        SELECT TOP 1 SumInsured
        FROM FarmersInsurance
        ORDER BY FarmersPremiumAmount DESC
    );
--  FindsrcDistrictNamewhere farmers� premium amount is higher than average farmers� premiumamount of the state with highest total population
-- Step 1: Get the state with highest total population
WITH StatePopulation AS (
    SELECT 
        srcStateName,
        SUM(TotalPopulationUrban + TotalPopulationRural) AS TotalPopulation
    FROM FarmersInsurance
    GROUP BY srcStateName
),
MaxPopState AS (
    SELECT TOP 1 srcStateName
    FROM StatePopulation
    ORDER BY TotalPopulation DESC
),
AvgPremium AS (
    SELECT 
        AVG(FarmersPremiumAmount) AS AvgStatePremium
    FROM FarmersInsurance
    WHERE srcStateName = (SELECT srcStateName FROM MaxPopState)
)
-- Step 2 & 3: Filter districts
SELECT DISTINCT 
    srcDistrictName,
    FarmersPremiumAmount
FROM 
    FarmersInsurance
WHERE 
    srcStateName = (SELECT srcStateName FROM MaxPopState)
    AND FarmersPremiumAmount > (SELECT AvgStatePremium FROM AvgPremium);



--Avanced SQL Functions (Window Functions)

-- UseROW_NUMBER()to rank records ordered by the total farmers covered.
SELECT 
    srcStateName,
    srcDistrictName,
    srcYear,
    TotalFarmersCovered,
    ROW_NUMBER() OVER (ORDER BY TotalFarmersCovered DESC) AS RowRank
FROM 
    FarmersInsurance;


-- UseRANK()to rank districts based on insured sum partitioned bysrcStateName
SELECT 
    srcStateName,
    srcDistrictName,
    SumInsured,
    RANK() OVER (
        PARTITION BY srcStateName 
        ORDER BY SumInsured DESC
    ) AS DistrictRank
FROM 
    FarmersInsurance;


-- UseSUM()window function to calculate cumulative farmers� premium amount for each districtpartitioned bysrcStateNam
SELECT 
    srcStateName,
    srcDistrictName,
    srcYear,
    FarmersPremiumAmount,
    SUM(FarmersPremiumAmount) OVER (
        PARTITION BY srcStateName, srcDistrictName 
        ORDER BY srcYear
    ) AS CumulativePremium
FROM 
    FarmersInsurance;



--Data Integrity (Constraints, Foreign Keys)


-- Create a tabledistrictswithDistrictCodeas the primary key and columns forDistrictNameandStateCode. Create another tablestateswithStateCodeas primary key and column forStateName
CREATE TABLE districts (
    DistrictCode INT PRIMARY KEY,
    DistrictName VARCHAR(100),
    StateCode INT
);


-- dd a foreign key constraint to the districts table referencingStateCodefrom the states table
CREATE TABLE states (
    StateCode INT PRIMARY KEY,
    StateName VARCHAR(100)
);


ALTER TABLE districts
ADD CONSTRAINT FK_Districts_States
FOREIGN KEY (StateCode) REFERENCES states(StateCode);



-- UPDATEandDELETE

-- 27. UpdateFarmersPremiumAmountto 500.0 INR whererowID = 1
UPDATE FarmersInsurance
SET FarmersPremiumAmount = 500.0
WHERE rowID = 1;


-- 28. Update year to 2021 for records wheresrcStateName = "HIMACHAL PRADESH"
UPDATE FarmersInsurance
SET srcYear = 2021
WHERE srcStateName = 'HIMACHAL PRADESH';

-- 29. Delete records whereTotalFarmersCovered < 10,000andYear = 2020
DELETE FROM FarmersInsurance
WHERE TotalFarmersCovered < 10000 AND srcYear = 2020;



